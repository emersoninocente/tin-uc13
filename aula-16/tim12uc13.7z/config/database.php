<?php
// config/database.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'biblioteca');
define('DB_USER', 'tim12uc13');
define('DB_PASS', 'P@ssw0rd');
define('DB_PORT','8080');
define('DB_CHARSET', 'utf8mb4');