<?php
// index.php
header('Location: http://localhost/tim12uc13/src/Views/listarUsuarios.php');
exit;
?>